package com.example.stokpenjualan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.withTransaction
import com.example.stokpenjualan.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }.format(value)

private class MainViewModel(private val db: AppDatabase) : ViewModel() {
    val products = db.productDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val lowStock = db.productDao().observeLowStock().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val productCount = db.productDao().observeCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val revenueToday = db.saleDao().observeRevenueSince(dayStart()).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val saleCountToday = db.saleDao().observeSaleCountSince(dayStart()).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addProduct(name: String, code: String, buy: Long, sell: Long, stock: Int, minStock: Int) = viewModelScope.launch {
        db.productDao().insert(Product(name = name, code = code, buyPrice = buy, sellPrice = sell, stock = stock, minStock = minStock))
    }

    fun deleteProduct(p: Product) = viewModelScope.launch { db.productDao().delete(p) }

    fun sell(p: Product, qty: Int, paid: Long) = viewModelScope.launch {
        if (qty <= 0 || qty > p.stock) return@launch
        val total = p.sellPrice * qty
        if (paid < total) return@launch
        db.withTransaction {
            val saleId = db.saleDao().insertSale(Sale(total = total, paid = paid, changeAmount = paid - total))
            db.saleDao().insertItems(listOf(SaleItem(saleId = saleId, productId = p.id, productName = p.name, qty = qty, price = p.sellPrice, subtotal = total)))
            db.productDao().changeStock(p.id, -qty)
        }
    }

    private fun dayStart(): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }
}

private class VMFactory(private val db: AppDatabase) : androidx.lifecycle.ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(db) as T
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent { MaterialTheme { App(viewModel(factory = VMFactory(db))) } }
    }
}

@Composable
fun App(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Stok & Penjualan") }) },
        bottomBar = {
            NavigationBar {
                listOf("Dashboard", "Produk", "Penjualan").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> Dashboard(vm, Modifier.padding(pad))
            1 -> Products(vm, Modifier.padding(pad))
            else -> Sales(vm, Modifier.padding(pad))
        }
    }
}

@Composable
fun Dashboard(vm: MainViewModel, modifier: Modifier) {
    val count by vm.productCount.collectAsState()
    val revenue by vm.revenueToday.collectAsState()
    val sales by vm.saleCountToday.collectAsState()
    val low by vm.lowStock.collectAsState()
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ringkasan Hari Ini", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Omzet"); Text(rupiah(revenue), style = MaterialTheme.typography.headlineMedium)
            Text("$sales transaksi")
        }}
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("Jumlah produk: $count")
            Text("Stok menipis: ${low.size}")
        }}
        if (low.isNotEmpty()) {
            Text("Stok Menipis", style = MaterialTheme.typography.titleLarge)
            low.take(5).forEach { Text("• ${it.name}: ${it.stock} ${it.unit}") }
        }
    }
}

@Composable
fun Products(vm: MainViewModel, modifier: Modifier) {
    val products by vm.products.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("Tambah Produk") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text("Jual: ${rupiah(p.sellPrice)} • Stok: ${p.stock} ${p.unit}")
                            if (p.code.isNotBlank()) Text("Kode: ${p.code}")
                        }
                        TextButton(onClick = { vm.deleteProduct(p) }) { Text("Hapus") }
                    }
                }
            }
        }
    }
    if (showAdd) AddProductDialog({ showAdd = false }) { name, code, buy, sell, stock, min ->
        vm.addProduct(name, code, buy, sell, stock, min); showAdd = false
    }
}

@Composable
fun AddProductDialog(onDismiss: () -> Unit, onSave: (String,String,Long,Long,Int,Int)->Unit) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("5") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Produk") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(code, { code = it }, label = { Text("Kode") }, singleLine = true)
                OutlinedTextField(buy, { buy = it.filter(Char::isDigit) }, label = { Text("Harga beli") }, singleLine = true)
                OutlinedTextField(sell, { sell = it.filter(Char::isDigit) }, label = { Text("Harga jual") }, singleLine = true)
                OutlinedTextField(stock, { stock = it.filter(Char::isDigit) }, label = { Text("Stok awal") }, singleLine = true)
                OutlinedTextField(min, { min = it.filter(Char::isDigit) }, label = { Text("Batas stok minimum") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank(), onClick = {
                onSave(name, code, buy.toLongOrNull() ?: 0, sell.toLongOrNull() ?: 0, stock.toIntOrNull() ?: 0, min.toIntOrNull() ?: 5)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun Sales(vm: MainViewModel, modifier: Modifier) {
    val products by vm.products.collectAsState()
    var selected by remember { mutableStateOf<Product?>(null) }
    var qty by remember { mutableStateOf("1") }
    var paid by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Penjualan Cepat", style = MaterialTheme.typography.headlineSmall)
        if (products.isEmpty()) Text("Belum ada produk. Tambahkan produk terlebih dahulu.")
        products.forEach { p ->
            OutlinedButton(onClick = { selected = p }, modifier = Modifier.fillMaxWidth()) {
                Text("${p.name} • ${rupiah(p.sellPrice)} • stok ${p.stock}")
            }
        }
        selected?.let { p ->
            HorizontalDivider()
            Text("Dipilih: ${p.name}")
            OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("Jumlah") }, singleLine = true)
            OutlinedTextField(paid, { paid = it.filter(Char::isDigit) }, label = { Text("Uang diterima") }, singleLine = true)
            val total = p.sellPrice * (qty.toIntOrNull() ?: 0)
            Text("Total: ${rupiah(total)}")
            Button(
                enabled = (qty.toIntOrNull() ?: 0) in 1..p.stock && (paid.toLongOrNull() ?: 0) >= total && total > 0,
                onClick = { vm.sell(p, qty.toInt(), paid.toLong()); selected = null; qty = "1"; paid = "" },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan Penjualan") }
        }
    }
}
