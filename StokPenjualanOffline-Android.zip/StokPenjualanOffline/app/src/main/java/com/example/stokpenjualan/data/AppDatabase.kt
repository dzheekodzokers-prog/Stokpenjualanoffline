package com.example.stokpenjualan.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String = "",
    val buyPrice: Long = 0,
    val sellPrice: Long = 0,
    val stock: Int = 0,
    val minStock: Int = 5,
    val unit: String = "pcs"
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val total: Long,
    val paid: Long,
    val changeAmount: Long
)

@Entity(tableName = "sale_items")
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productId: Long,
    val productName: String,
    val qty: Int,
    val price: Long,
    val subtotal: Long
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name")
    fun observeAll(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE stock <= minStock ORDER BY stock")
    fun observeLowStock(): Flow<List<Product>>

    @Insert suspend fun insert(product: Product): Long
    @Update suspend fun update(product: Product)
    @Delete suspend fun delete(product: Product)

    @Query("UPDATE products SET stock = stock + :delta WHERE id = :id")
    suspend fun changeStock(id: Long, delta: Int)

    @Query("SELECT COUNT(*) FROM products")
    fun observeCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(stock * sellPrice), 0) FROM products")
    fun observeStockValue(): Flow<Long>
}

@Dao
interface SaleDao {
    @Insert suspend fun insertSale(sale: Sale): Long
    @Insert suspend fun insertItems(items: List<SaleItem>)

    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE createdAt >= :start")
    fun observeRevenueSince(start: Long): Flow<Long>

    @Query("SELECT COUNT(*) FROM sales WHERE createdAt >= :start")
    fun observeSaleCountSince(start: Long): Flow<Int>

    @Query("SELECT * FROM sales ORDER BY createdAt DESC LIMIT 100")
    fun observeRecent(): Flow<List<Sale>>
}

@Database(
    entities = [Product::class, Sale::class, SaleItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun saleDao(): SaleDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "stok_penjualan.db"
                ).build().also { INSTANCE = it }
            }
    }
}
