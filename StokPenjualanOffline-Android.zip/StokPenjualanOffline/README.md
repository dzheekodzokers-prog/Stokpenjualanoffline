# Stok & Penjualan Offline — Android

Versi awal aplikasi kasir/stok offline.

## Fitur
- Database lokal Room (tanpa internet)
- Dashboard omzet dan jumlah transaksi hari ini
- CRUD produk dasar
- Stok minimum
- Penjualan cepat
- Pengurangan stok otomatis saat transaksi
- Perhitungan total dan kembalian

## Cara membuka
1. Buka folder ini dengan Android Studio terbaru.
2. Biarkan Gradle melakukan sync dan mengunduh dependency.
3. Pilih emulator/perangkat Android.
4. Run `app`.

Package: `com.example.stokpenjualan`
Minimum Android: API 26.
